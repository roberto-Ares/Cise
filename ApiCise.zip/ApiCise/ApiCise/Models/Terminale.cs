﻿using System;
using System.Collections.Generic;

namespace ApiCise.Models
{
    public partial class Terminale
    {
        public int IdTerminal { get; set; }
        public int IdFab { get; set; }
        public int IdEstado { get; set; }
        public DateTime FechaFabricacion { get; set; }
        public DateTime FechaEstado { get; set; }
        public string TeminalDesc { get; set; } = null!;
        public string TerminalName { get; set; } = null!;

        public virtual Estado IdEstadoNavigation { get; set; } = null!;
        public virtual Fabricante IdFabNavigation { get; set; } = null!;
    }
}
