﻿using System;
using System.Collections.Generic;

namespace ApiCise.Models
{
    public partial class Estado
    {
        public Estado()
        {
            Terminales = new HashSet<Terminale>();
        }

        public int IdEstado { get; set; }
        public string? EstadoName { get; set; }
        public string? EstadoDesc { get; set; }

        public virtual ICollection<Terminale> Terminales { get; set; }
    }
}
