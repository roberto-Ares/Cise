﻿using System;
using System.Collections.Generic;
using ApiCise.Models;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;

namespace ApiCise.Contexto
{
    public partial class SICEContext : DbContext
    {
        public SICEContext()
        {
        }

        public SICEContext(DbContextOptions<SICEContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Estado> Estados { get; set; } = null!;
        public virtual DbSet<Fabricante> Fabricantes { get; set; } = null!;
        public virtual DbSet<Terminale> Terminales { get; set; } = null!;

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {

        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Estado>(entity =>
            {
                entity.HasKey(e => e.IdEstado);

                entity.ToTable("estado");

                entity.Property(e => e.IdEstado).HasColumnName("id_estado");

                entity.Property(e => e.EstadoDesc)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("estado_desc");

                entity.Property(e => e.EstadoName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("estado_name");
            });

            modelBuilder.Entity<Fabricante>(entity =>
            {
                entity.HasKey(e => e.IdFab);

                entity.ToTable("fabricantes");

                entity.Property(e => e.IdFab).HasColumnName("id_fab");

                entity.Property(e => e.FabDesc)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("fab_desc");

                entity.Property(e => e.FabName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("fab_name");
            });

            modelBuilder.Entity<Terminale>(entity =>
            {
                entity.HasKey(e => e.IdTerminal);

                entity.ToTable("terminales");

                entity.Property(e => e.IdTerminal).HasColumnName("id_terminal");

                entity.Property(e => e.FechaEstado)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_estado");

                entity.Property(e => e.FechaFabricacion)
                    .HasColumnType("datetime")
                    .HasColumnName("fecha_fabricacion");

                entity.Property(e => e.IdEstado).HasColumnName("id_estado");

                entity.Property(e => e.IdFab).HasColumnName("id_fab");

                entity.Property(e => e.TeminalDesc)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("teminal_desc");

                entity.Property(e => e.TerminalName)
                    .HasMaxLength(50)
                    .IsUnicode(false)
                    .HasColumnName("terminal_name");

                entity.HasOne(d => d.IdEstadoNavigation)
                    .WithMany(p => p.Terminales)
                    .HasForeignKey(d => d.IdEstado)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_terminales_estado");

                entity.HasOne(d => d.IdFabNavigation)
                    .WithMany(p => p.Terminales)
                    .HasForeignKey(d => d.IdFab)
                    .OnDelete(DeleteBehavior.ClientSetNull)
                    .HasConstraintName("FK_terminales_fabricantes");
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}
