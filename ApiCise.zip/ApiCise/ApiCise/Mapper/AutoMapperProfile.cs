﻿using ApiCise.Models;
using ApiCise.ModelsResponse;
using AutoMapper;

namespace ApiCise.Mapper
{
    public class AutoMapperProfile:Profile
    {
        public AutoMapperProfile() {

            CreateMap<Estado,EstadoResponse> ();
            CreateMap<Fabricante, FabricanteResponse>();
            CreateMap<Terminale, TerminaleResponse>();
        }
    }
}
