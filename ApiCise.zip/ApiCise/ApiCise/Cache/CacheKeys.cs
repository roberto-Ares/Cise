﻿namespace ApiCise.Cache
{
    public class CacheKeys
    {
        public static string Terminale => "_terminale";
        public static string Fabricante => "_fabricante";
        public static string Estado => "_estado";
    }
}
