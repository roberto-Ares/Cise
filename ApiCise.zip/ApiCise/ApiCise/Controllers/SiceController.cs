﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ApiCise.Models;
using ApiCise.Contexto;
using System.Net;
using ApiCise.Queries;
using AutoMapper;
using ApiCise.ModelsResponse;
using System.Collections.Generic;
using ApiCise.Cache;
using Microsoft.Extensions.Caching.Memory;

namespace ApiCise.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class SiceController : ControllerBase
    {
        private readonly CiseQuerieService _querieservice;
        private IMemoryCache _cacheProvider;
        public SiceController(CiseQuerieService queryservice, IMemoryCache cacheProvider)
        {
            _querieservice = queryservice;
            _cacheProvider = cacheProvider;
        }
        [HttpGet("Estado")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public IActionResult GetEstado()
        {
            if (!_cacheProvider.TryGetValue(CacheKeys.Estado, out var estados))
            {
                var cacheEntryOptions = new MemoryCacheEntryOptions
                {
                    AbsoluteExpiration = DateTime.Now.AddMinutes(5),
                    SlidingExpiration = TimeSpan.FromMinutes(2),
                    Size = 1024,
                };
                estados = _querieservice.GetEstado();
                _cacheProvider.Set(CacheKeys.Estado, estados, cacheEntryOptions);
                
            }
                
            if (estados == null)
                return NotFound("Estados no encontrados");
            return Ok(estados);
        }

        [HttpGet("Fabricante")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public IActionResult GetFabricante()
        {
            if (!_cacheProvider.TryGetValue(CacheKeys.Fabricante, out var fabricante))
            {
                var cacheEntryOptions = new MemoryCacheEntryOptions
                {
                    AbsoluteExpiration = DateTime.Now.AddMinutes(5),
                    SlidingExpiration = TimeSpan.FromMinutes(2),
                    Size = 1024,
                };
                fabricante = _querieservice.GetFabricante();
                _cacheProvider.Set(CacheKeys.Estado, fabricante, cacheEntryOptions);
                
            }
            if (fabricante == null)
                return NotFound("Fabricantes no encontrados");
            return Ok(fabricante);
        }
        [HttpGet("Terminales")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public IActionResult GetTerminales()
        {
            if (!_cacheProvider.TryGetValue(CacheKeys.Terminale, out var terminale))
            {
                var cacheEntryOptions = new MemoryCacheEntryOptions
                {
                    AbsoluteExpiration = DateTime.Now.AddMinutes(5),
                    SlidingExpiration = TimeSpan.FromMinutes(2),
                    Size = 1024,
                };
                terminale = _querieservice.GetTerminal();
                _cacheProvider.Set(CacheKeys.Estado, terminale, cacheEntryOptions);
                
            }
            if (terminale == null)
                return NotFound("Terminales no encontrados");
            return Ok(terminale);
        }
        [HttpGet("QueryTerminales")]
        [ProducesResponseType((int)HttpStatusCode.OK)]
        [ProducesResponseType((int)HttpStatusCode.BadRequest)]
        public IActionResult GetTerminalesQuery()
        {
            if (!_cacheProvider.TryGetValue(CacheKeys.Terminale, out var terminalequery))
            {
                var cacheEntryOptions = new MemoryCacheEntryOptions
                {
                    AbsoluteExpiration = DateTime.Now.AddMinutes(5),
                    SlidingExpiration = TimeSpan.FromMinutes(2),
                    Size = 1024,
                };
                terminalequery = _querieservice.GetTerminalQuery();
                _cacheProvider.Set(CacheKeys.Estado, terminalequery, cacheEntryOptions);
                
            }
            if (terminalequery == null)
                return NotFound("Terminales no encontrados");
            return Ok(terminalequery);
        }
    }
}
