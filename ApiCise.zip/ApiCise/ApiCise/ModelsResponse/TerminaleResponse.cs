﻿using System;
using System.Collections.Generic;

namespace ApiCise.ModelsResponse
{
    public partial class TerminaleResponse
    {
        #region Propiedades
        public int IdTerminal { get; set; }
        public int IdFab { get; set; }
        public int IdEstado { get; set; }
        public DateTime FechaFabricacion { get; set; }
        public DateTime FechaEstado { get; set; }
        public string TeminalDesc { get; set; } = null!;
        public string TerminalName { get; set; } = null!;
        #endregion
    }
}
