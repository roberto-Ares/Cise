﻿using System;
using System.Collections.Generic;

namespace ApiCise.ModelsResponse
{
    public partial class EstadoResponse
    {
        #region Propiedades
        public int IdEstado { get; set; }
        public string? EstadoName { get; set; }
        public string? EstadoDesc { get; set; }
        #endregion

    }
}
