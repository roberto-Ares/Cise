﻿using System;
using System.Collections.Generic;

namespace ApiCise.ModelsResponse
{
    public partial class TerminaleQueryResponse
    {
        #region Propiedades
        public string? FabName { get; set; }
        public string TeminalDesc { get; set; } = null!;
        public string TerminalName { get; set; } = null!;
        public string? EstadoName { get; set; }
        public DateTime FechaFabricacion { get; set; }
        public DateTime FechaEstado { get; set; }
        #endregion
    }
}
