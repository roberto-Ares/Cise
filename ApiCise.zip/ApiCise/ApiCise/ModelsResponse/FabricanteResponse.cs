﻿using System;
using System.Collections.Generic;

namespace ApiCise.ModelsResponse
{
    public partial class FabricanteResponse
    {
        #region Propiedades
        public int IdFab { get; set; }
        public string? FabName { get; set; }
        public string? FabDesc { get; set; }
        #endregion

    }
}
