using Microsoft.EntityFrameworkCore;
using ApiCise.Contexto;
using System.Text.Json.Serialization;
using Autofac;
using ApiCise.Queries;
using Autofac.Core;

var builder = WebApplication.CreateBuilder(args);


// Add services to the container.

builder.Services.AddControllers();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
//Configuramos el automapper
builder.Services.AddAutoMapper(AppDomain.CurrentDomain.GetAssemblies());
//Configurmos cache
builder.Services.AddMemoryCache();
//Configuramos el contexto para enlazarlo con la cadena de conexi�n
string CadenaConexion = builder.Configuration.GetConnectionString("CadenaSql");
builder.Services.AddDbContext<SICEContext>(opt => opt.UseSqlServer(CadenaConexion));

//Eviatar referencias ciclicas al devolver el json
builder.Services.AddControllers().AddJsonOptions(opt => {

    opt.JsonSerializerOptions.ReferenceHandler = ReferenceHandler.IgnoreCycles;
});


//builder.Services.AddTransient<ICiseQueriesService>();
builder.Services.AddTransient<CiseQuerieService>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.Run();
