﻿
using ApiCise.Contexto;
using ApiCise.Models;
using ApiCise.ModelsResponse;
using ApiCise.Queries;
using AutoMapper;
using Microsoft.Ajax.Utilities;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static Microsoft.EntityFrameworkCore.DbLoggerCategory;

namespace ApiCise.Queries
{
    public class CiseQuerieService  {

        private readonly SICEContext _dbconext;
        private readonly IMapper _mapper;
        public CiseQuerieService(SICEContext _contexto, IMapper mapper)
        {
            _dbconext = _contexto;
            _mapper = mapper;
        }

        public IEnumerable<EstadoResponse> GetEstado()
        {
         
            var result = _mapper.Map<List<EstadoResponse>>(_dbconext.Estados.ToList());
            return result;
        }
        public IEnumerable<FabricanteResponse> GetFabricante()
        {
            var result = _mapper.Map<List<FabricanteResponse>>(_dbconext.Fabricantes.ToList());
            return result;
        }
        public IEnumerable<TerminaleResponse> GetTerminal()
        {
            var result = _mapper.Map<List<TerminaleResponse>>(_dbconext.Terminales.ToList());
            return result;
        }
        public IEnumerable<TerminaleQueryResponse> GetTerminalQuery()
        {
            var result = from i in _dbconext.Terminales.Include(e => e.IdEstadoNavigation).Include(f => f.IdFabNavigation).ToList()
                          select new TerminaleQueryResponse
                          {
                            TeminalDesc = i.TeminalDesc,
                            TerminalName = i.TerminalName,
                            FechaEstado = i.FechaEstado,
                            FechaFabricacion = i.FechaFabricacion,
                            FabName = i.IdFabNavigation.FabName,
                            EstadoName = i.IdEstadoNavigation.EstadoName
                           };
            return result;
        }
    }

}
